jedna klasa = jedna odpowiedzialność

