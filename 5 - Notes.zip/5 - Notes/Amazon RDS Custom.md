Created: 2026-02-11  10:34
___
Note:

>[! Important]
>**Amazon RDS Custom** to wyspecjalizowana usługa bazodanowa przeznaczona dla silników:
>- **Oracle** 
>- **Microsoft SQL Server**, 
>
>która łączy zalety zarządzanej usługi RDS z możliwością głębokiej personalizacji.

Oto kluczowe informacje na temat tej usługi:

1. Pełna kontrola nad systemem (Full Control)

 **pełny dostęp administracyjny do warstwy OS oraz bazy danych**. 

Dzięki temu możesz:
• **Konfigurować specyficzne ustawienia** systemu operacyjnego i bazy danych.
• **Instalować własne łatki (patches)** i oprogramowanie firm trzecich.
• **Włączać natywne funkcje** bazy danych, które nie są wspierane w standardowym modelu RDS.


![[Pasted image 20260211104014.png]]

___
Metadata:

```yaml
---
type: tool    # concept | service | comparison
language: aws
---
```

Status: #pending
Tags: #aws #rds
